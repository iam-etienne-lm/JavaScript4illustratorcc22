Récap ouverture (quand le logiciel est bien configuré)



•	Lors de l’ouverture d’un fichier on valide généralement la première fenêtre « profils » ou « modèles » :
 



•	Puis la seconde comprenant le choix du calque plots-caméra
 




Petit récap pour le contrôle avec illustrations :

•	Liste des calques sérigraphie lors de l’import, ensuite on supprime le calque 12 ainsi que l’équerre VIDEO JET (CTRL+A > F6 > Suppr)




•	Avec la croix sur le plot caméra, le repérage est bon












•	Pour faire réapparaitre la fenêtre de choix du profil, il sélectionner l’option « Demander à nouveau » dans le menu Aide  (Tuyau donné par Laurent)
NB : réaffiche les fenêtres « à postériori » : en effet si ces options ont déjà été définies, il faut créer un nouveau fichier.






















•	Afin d’ajuster les plots caméra, il faut aller sur Repère > Recherche


































En PJ le nuancier ADH Deco pour info.

Cordialement,

Etienne LEROY 
Technicien PAO
 
Tel. +33 5 62 74 53 05
www.adhetec.com

ZAC de Gramont – 8 Rue Jean Mermoz – 31770 COLOMIERS – France

 

